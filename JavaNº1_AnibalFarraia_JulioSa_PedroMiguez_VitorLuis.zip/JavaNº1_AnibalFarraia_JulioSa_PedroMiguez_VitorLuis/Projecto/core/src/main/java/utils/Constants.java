package utils;

public class Constants {
    public static final String HOST="http://localhost:8080";
}
