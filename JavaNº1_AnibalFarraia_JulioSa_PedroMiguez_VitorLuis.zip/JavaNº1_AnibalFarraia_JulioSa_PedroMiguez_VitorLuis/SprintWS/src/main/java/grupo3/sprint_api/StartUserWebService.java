package grupo3.sprint_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartUserWebService {

	public static void main(String[] args) {
		SpringApplication.run(StartUserWebService.class, args);
	}

}
